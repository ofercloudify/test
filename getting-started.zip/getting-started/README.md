# Getting Started Example

See [Multi-Cloud Orchestration](https://docs.cloudify.co/latest/trial_getting_started/examples/multi_cloud/) for the guide.
