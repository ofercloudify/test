#!/bin/bash -e
rm -f /tmp/index.html

