#!/bin/bash -e
ctx download-resource-and-render resources/index.html /tmp/index.html
