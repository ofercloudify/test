#!/bin/bash -e

sudo systemctl daemon-reload
sudo systemctl enable wildfly