#!/bin/bash -e

sudo systemctl start wildfly