#!/bin/bash -e

sudo systemctl stop wildfly